#include "pthread_impl.h"

int pthread_mutexattr_destroy(pthread_mutexattr_t *a)
{
	return 0;
}
