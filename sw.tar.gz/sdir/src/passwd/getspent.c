#include "pwf.h"

void setspent()
{
}

void endspent()
{
}

struct spwd *getspent()
{
	return 0;
}
