#include <math.h>

long lround(double x)
{
	return round(x);
}
